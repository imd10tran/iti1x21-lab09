public class TestL09 {

  public static void main(String[] args) {
    TestUtils.runClass(TestL9SecretMessage.class);
    TestUtils.runClass(TestL9PlayList.class);
  }

}
